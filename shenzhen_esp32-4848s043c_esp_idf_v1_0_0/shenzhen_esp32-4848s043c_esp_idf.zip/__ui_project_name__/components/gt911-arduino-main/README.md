# GT911 Library

This is a library for the GT911 capacitive touch screen

