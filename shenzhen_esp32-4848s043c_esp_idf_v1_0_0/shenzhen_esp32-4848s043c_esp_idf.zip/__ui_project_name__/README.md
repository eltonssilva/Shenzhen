# ESP32-4848S043C - MaTouch 4-inch Parallel 480x480 IPS TFT with Touch - ESP-IDF (with touch-screen)


## Prerequisites

ESP-IDF version 4.4 should be installed on your system. (The included Arduino-GFX driver and its backend is compatible with this version of IDF.)

- Install ESP-IDF on Windows: [Description page](https://dl.espressif.com/dl/idf-installer/esp-idf-tools-setup-offline-4.4.6.exe)
- Install ESP-IDF on Linux/MacOS: [Description page](https://docs.espressif.com/projects/esp-idf/en/latest/esp32/get-started/linux-macos-setup.html)

(If you cloned ESP-IDF from github you have the possibility to change its version in place by checking out to a different release-branch in the cloned `esp-idf` folder, `git checkout remotes/origin/release/v4.4` in this case. The ESP32-S3 toolchain should also be installed with `~/esp/esp-idf/install.sh esp32s3` and `git submodule update --init --recursive` should be used to update ESP-IDF submobules.)


## Building the project

There are convenience scripts like `build.sh/build.bat` which you can use, but you can build the project with `idf.py build` too directly.
(The scripts will try to bring the ESP-IDF commands in, but useng `idf.py` requires a command prompt that already ran `export`. See the build-scripts or ESP-IDF documentation for more info.)


## Flashing the built project to the device

You can use the `flash.sh/flash.bat` scripts to flash the generated code to the device, alternatively `idf.py flash`.


## Misc. notes

This project uses `main/lv_conf.h` to configure LVGL instead of `sdkconfig` that most ESP-IDF projects use. This is better for SquareLine Studio because it can enable the resized Montserrat fonts and configure drives in `lv_conf.h`.
(The `sdkconfig` can still be used for other aspects of ESP-IDF with `idf.py menuconfig`, and if you want LVGL to use it for LVGL instead of lv_conf.h, you should enable `LV_CONF_SKIP` and set LVGL in components menupoint of menuconfig."

If you'd like to use a GUI workflow there's an IDE made by Espressif containing ESP-IDF, called Espressif-IDE which is based on Eclipse CDT: [Espressif-IDE Windows installer](https://dl.espressif.com/dl/idf-installer/espressif-ide-setup-2.11.1-with-esp-idf-5.1.2.exe?)

Please avoid folder-names and filenames containing non-ASCII (special/accented/foreign) characters for the installed tools and your exported projects. Some build-tools and terminals/OS-es don't handle those characters well or interpret them differently, which can cause issues during the build-process.


2024 SquareLine

