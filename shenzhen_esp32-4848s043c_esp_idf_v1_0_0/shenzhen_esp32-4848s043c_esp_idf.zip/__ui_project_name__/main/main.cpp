//Makerfabs ESP32-4848S043C board-template main source file

#include "esp_log.h"
#include <Arduino_GFX_Library.h>
#include <lvgl.h>
#include <ui.h>


#define TAG "__UI_PROJECT_NAME__"

enum BoardConstants { GFX_BL=38, LVGL_BUFFER_RATIO=6 };


static const uint16_t screenWidth = __UI_PROJECT_HOR_RES__;
static const uint16_t screenHeight = __UI_PROJECT_VER_RES__;

static lv_disp_draw_buf_t draw_buf;
static lv_color_t *disp_draw_buf;

Arduino_ESP32RGBPanel *bus = new Arduino_ESP32RGBPanel(
    39 /* CS */, 48 /* SCK */, 47 /* SDA */,
    18 /* DE */, 17 /* VSYNC */, 16 /* HSYNC */, 21 /* PCLK */,
    11 /* R0 */, 12 /* R1 */, 13 /* R2 */, 14 /* R3 */, 0 /* R4 */,
    8 /* G0 */, 20 /* G1 */, 3 /* G2 */, 46 /* G3 */, 9 /* G4 */, 10 /* G5 */,
    4 /* B0 */, 5 /* B1 */, 6 /* B2 */, 7 /* B3 */, 15 /* B4 */
);


Arduino_ST7701_RGBPanel *gfx = new Arduino_ST7701_RGBPanel(
  bus, GFX_NOT_DEFINED /* RST */, 0 /* rotation */,
  false /* IPS */, 480 /* width */, 480 /* height */,
  st7701_type1_init_operations, sizeof(st7701_type1_init_operations),
  true /* BGR */
  );


#include "touch.h"


/* Display flushing */
void my_disp_flush (lv_disp_drv_t *disp, const lv_area_t *area, lv_color_t *color_p)
{
    uint32_t w = (area->x2 - area->x1 + 1);
    uint32_t h = (area->y2 - area->y1 + 1);

#if (LV_COLOR_16_SWAP != 0)
    gfx->draw16bitBeRGBBitmap( area->x1, area->y1, (uint16_t*) &color_p->full, w, h );
#else
    gfx->draw16bitRGBBitmap( area->x1, area->y1, (uint16_t*) &color_p->full, w, h );
#endif
    lv_disp_flush_ready(disp);
}


/*Read the touchpad*/
void my_touchpad_read (lv_indev_drv_t *indev_driver, lv_indev_data_t *data)
{
    if ( touch_has_signal() ) {
        if ( touch_touched() ) {
            data->state = LV_INDEV_STATE_PR;
            /*Set the coordinates*/
            data->point.x = touch_last_x;
            data->point.y = touch_last_y;
        }
        else if ( touch_released() ) {
            data->state = LV_INDEV_STATE_REL;
        }
    }
    else {
        data->state = LV_INDEV_STATE_REL;
    }
}


extern "C" void app_main ()
{
    // Init touch device
    touch_init();

    // Init Display
    gfx->begin();
    gfx->fillScreen(BLACK);

    pinMode(GFX_BL, OUTPUT);
    digitalWrite(GFX_BL, HIGH);

    lv_init();
    //screenWidth = gfx->width(); screenHeight = gfx->height();

#ifdef ESP32
    disp_draw_buf = (lv_color_t *) heap_caps_malloc( sizeof(lv_color_t) * screenWidth * LVGL_BUFFER_RATIO, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT );
#else
    disp_draw_buf = (lv_color_t *) malloc( sizeof(lv_color_t) * screenWidth * LVGL_BUFFER_RATIO );
#endif
    if (!disp_draw_buf) {
        ESP_LOGI( TAG, "LVGL disp_draw_buf allocate failed!" );
    }
    else {
        lv_disp_draw_buf_init( &draw_buf, disp_draw_buf, NULL, screenWidth * LVGL_BUFFER_RATIO );

        /*Initialize the display*/
        static lv_disp_drv_t disp_drv;
        lv_disp_drv_init( &disp_drv );
        /*Change the following line to your display resolution*/
        disp_drv.hor_res = screenWidth;
        disp_drv.ver_res = screenHeight;
        disp_drv.flush_cb = my_disp_flush;
        disp_drv.draw_buf = &draw_buf;
        lv_disp_drv_register( &disp_drv );

        /*Initialize the (dummy) input device driver*/
        static lv_indev_drv_t indev_drv;
        lv_indev_drv_init( &indev_drv );
        indev_drv.type = LV_INDEV_TYPE_POINTER;
        indev_drv.read_cb = my_touchpad_read;
        lv_indev_drv_register( &indev_drv );

        ui_init();

        ESP_LOGI( TAG, "Initialization done." );

        while (1) {
            lv_timer_handler();
            delay(10); //together with LV_INDEV_DEF_READ_PERIOD it should be bigger than LV_DISP_DEF_REFR_PERIOD, to avoid button-press glitches (e.g. in Smart Gadget example)
        }
    }
}


